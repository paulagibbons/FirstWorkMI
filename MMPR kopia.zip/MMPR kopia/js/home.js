


/* Hämtar APi för filmkategorier som sparas i variabeln navBarInfo */
 $.getJSON("http://medieinstitutet-wie-products.azurewebsites.net/api/categories", function (navBarInfo) {
            var navbar = $("#navbar"); 
            var ul = $("<ul class='nav navbar-nav'>"); 
           
           for (i = 0; i < navBarInfo.length; i++) { /* Loopar all data från anropet till api/categories */
               
                var li = $("<li>"); /* En variabel för att skapa li tag */
                
                var a =$("<a />").attr("href", "productCategory.html?category=" + navBarInfo[i].id).attr("id", navBarInfo[i].name).text(navBarInfo[i].name).addClass("list-group-item");
                /* Skapar upp en a-tagg. alla .attr ger a-taggen olika attribut */
                
                a.appendTo(li); /* lägga till a taggen under li taggen. */
                li.appendTo(ul); /* li-taggen ska ligga under ul-taggen. */

            }
            ul.appendTo(navbar); /* ul-taggen lägger sig under navbar-variabeln (som vi har namngett på rad 11) */
        });

$.ajax({
    url: "https://medieinstitutet-wie-products.azurewebsites.net/api/random?number=4",
    type: "GET",
    headers: { "Accept": "application/json" },
    success: function (data) {
        // console.log(data);
        var items = [];        
            $(data).each(function () {
                //var str = this.name
               //var res = str.replace(/\s/g, "");
               
               items.push(
                   "<div class='col-lg-3'>" +
                   //"<img id=" + res + " onclick='generateProductModal();' src=" + this.imageUrl + " height='225' width='150'/>" +
                   "<img id=" + this.id + " onclick='generateProductModal();' src=" + this.imageUrl + " height='225' width='150'/>" +
                       "<p> Price:" + this.price + "</p>" +   
                  
                   "</div>"
               );
            });
        $("#latestNews").html(items.join(''))
    }
});




// Loopa alla poster med each
$.ajax({
    url: "http://medieinstitutet-wie-products.azurewebsites.net/api/products",
    type: "GET",
    headers: { "Accept": "application/json" },
    success: function (data) {
        data.sort(function (a, b) { // Här är en sorteringsfunktion (.sort) som sorterar senast tillagda till att hamna överst i listan/
            return new Date(b.added).getTime() - new Date(a.added).getTime()
        });
        // console.log(data);
        var carousel = $("#myCarousel"); 
            $(carousel).append("<div class='item active'><img src=" + data[0].imageUrl + " class='img-thumbnail'><div class='inner-inner'><h5>" + data[0].price + "</h5></div></div>");
        // här säger vi att i carousel ska det läggas en div med class='item active', och under det ska det finnas en bild utifrån datan från apiet
         //* eftersom vi har sorterat datan så vet vi att index 0 är den senast tillagda filmen. Nedan så upprepar vi samma sak fast med index 1 och index 2. */
        $(carousel).append("<div class='item'><img src=" + data[1].imageUrl + " class='img-thumbnail'><div class='inner-inner'><h5>" + data[1].price + "</h5></div></div>");
        $(carousel).append("<div class='item'><img src=" + data[2].imageUrl + " class='img-thumbnail'><div class='inner-inner'><h5>" + data[2].price + "</h5></div></div>");
        $(carousel).append("<div class='item'><img src=" + data[3].imageUrl + " class='img-thumbnail'><div class='inner-inner'><h5>" + data[3].price  + "</h5></div></div>");
    }
        
        
});




