function keepShoping() {

        location.href = "home.html";
}