// skapar mina radiobuddens med olika ID:n och oilka innebörder/värden! 

var button1 = {id:1, name:"Torsdag", choices: [{id:"Rabatt", value: "garden", name:"Rabatt"}, {id:"Fönsterputs", value: "window", name:"Fönsterputs"}]};  // Mina aktiviteter, med unika id

var button2 = {id:2, name:"Lördag", choices: [ {id:"Vind", value: "addict", name:"Städning av vind"}, {id:"Källare", value: "basement", name:"Städning av källare"}]};


function start(){
    
    var days = [button1, button2];   //en lista skapas
    
    //var text ="";
    
    
    for (var i = 0; i < days.length; i++){     //loopar igenom mina sporter
        
              
      var text = "<div class='days'>" +
                   "<ul>" +
                       "<li><a href='inlamning_Java1.html?id=" + days[i].id + "'>" + days[i].name + "</a></li>"+
                    
                   "</ul>" 
                 "</div>";
        
    
       
      
          
       document.getElementById("activities").innerHTML +=text;       //lägger mina nappar i en div       
     
}

    localStorage.setItem("days", JSON.stringify(days));             // sparar ner 
   



}



