function showT(){


var deltObj = JSON.parse(localStorage.getItem("1"));                //hämtar upp anmälningarna från ena aktiviteten
document.getElementById("showThursday").innerHTML = run();


  function run() {                                             //Skapar en funktion som plockar ur objekten/infon

        
      var LIs = "";

      for (var property in deltObj) {

       
          LIs += "<li> Förnamn: " + deltObj[property].firstName + "</li>";
          LIs += "<li> Efternamn: " + deltObj[property].lastName  + "</li>";
       
          LIs += "<li> Telefon: " + deltObj[property].number  + "</li>";
          LIs += "<li> Email: " + deltObj[property].eMail + "</li>";
       
          LIs += "<li> Kommentarer: " + deltObj[property].preferenses  + "</li>";
            LIs += "<li> Önskad Uppgift: " + deltObj[property].choices  + "</li>";
          LIs += "</br> <hr/>";

       
     
      }
      return "<ul>" + LIs + "</ul>";                       //Sätter infon i en lista

     }

}

function showS(){


var deltObj = JSON.parse(localStorage.getItem("2"));
document.getElementById("showSaturday").innerHTML = run();


  function run() {

        
      var LIs = "";

      for (var property in deltObj) {

       
          LIs += "<li> Förnamn: " + deltObj[property].firstName + "</li>";
          LIs += "<li> Efternamn: " + deltObj[property].lastName  + "</li>";
       
          LIs += "<li> Telefon: " + deltObj[property].number  + "</li>";
          LIs += "<li> Email: " + deltObj[property].eMail + "</li>";
       
          LIs += "<li> Kommentarer: " + deltObj[property].preferenses  + "</li>";
        LIs += "<li> Önskad Uppgift: " + deltObj[property].choices  + "</li>";
          LIs += "</br> <hr/>";

        
      }
      return "<ul>" + LIs + "</ul>";

     }

     }
