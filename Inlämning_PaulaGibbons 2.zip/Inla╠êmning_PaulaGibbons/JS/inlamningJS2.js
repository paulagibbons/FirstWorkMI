function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function choices(){
    var currentId = getParameterByName("id");
    
    var check;   //en lista skapas
    
    var activities = JSON.parse(localStorage.getItem("days"));   //hämtar upp listan days
    
    for(var i = 0; i < activities.length; i++) {            //loopar igenom listan
        if(activities[i].id == currentId) {
            check = activities[i].choices;
        }
    }
    
    
    for (var i = 0; i < check.length; i++){     //loopar igenom mina dagar/val
        
              
      var text = "";
    
        text += "<input type='radio' name='single' value='" + check[i].id + "' />";
       text += "<span>" + check[i].name + "</span><br/>";
        //skapas och namnet läggs till
 
      document.getElementById("radiobuttons").innerHTML +=text;
     


 localStorage.setItem("check", JSON.stringify(check));
    //knapparna läggs till i diven i html


}

}


function onRegisterPressed() {     //Hämtar vår info och lägger dem i lista.
    
    var currentId = getParameterByName("id");
    var deltObj = [];

    if (localStorage.getItem(currentId) != null) {   
          deltObj = JSON.parse(localStorage.getItem(currentId));
    }

  
   var firstName = document.getElementById("firstName").value;
   var lastName = document.getElementById("lastName").value;
   var number = document.getElementById("number").value;
   var eMail= document.getElementById("eMail").value;
   var preferenses = document.getElementById("preferenses").value;
    
    var userChoice = "";                                            //
    var myRadioButtons = document.getElementsByName("single");

      for(var i = 0; i < myRadioButtons.length; i++) {
            if(myRadioButtons[i].checked) {
                userChoice = myRadioButtons[i].value;
                 
            }
      }

      var userInput = {firstName: firstName, lastName: lastName, number: number, eMail: eMail,choices: userChoice,  preferenses: preferenses};
     
      deltObj.push(userInput);                                             //push funtion så att flera kan anmäla sig

      localStorage.setItem(currentId, JSON.stringify(deltObj));             //sparar uppgifterna
    


}

function initMap() {                                                
        var uluru = {lat: 59.316188, lng: 18.034918};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 15,
          center: uluru
        });
      
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }
//validering. fälten är = oifyll kommer alert kommer ett alertfönster komma upp. Om ifyllt skickas du vidare till atcksidan
function validate() {             
  var firstName = document.getElementById("firstName").value;
  if(firstName == "") {
      return false;
  }
 
  var lastName = document.getElementById("lastName").value;
  if(lastName == "") {
      return false;
  }

  var number = document.getElementById("number").value;
  if(number == "") {
      return false;
  }
 
  var eMail = document.getElementById("eMail").value;
  if(eMail == "") {
      return false;
  }
 
 
 
  var radio = document.forms[0];                                //validering för raioknapparna
  var radioSelected = false;
  for (var i = 0; i < radio.length; i++) {
          if (radio[i].checked) {                               //lopar igenom radioknapparna
              radioSelected = true;
      }
  }
 
  if(!radioSelected) {
      return false;
  }
 
  return true;
}

function hej() {        //funktionens som körs näv vi trycker på registeringsknappen
  var isValid = false;
  isValid = validate(); // om alla fält är ifyllda så skickas man vidare
 
  if(isValid) {
      onRegisterPressed();
    window.location = "file:///Users/Paula/Desktop/HTML_0914/Inlamning_java2.html"    //skickar vidare till tacksidan

  }
  else {
      alert("please enter all requried fields");
       
  }
       
}


  